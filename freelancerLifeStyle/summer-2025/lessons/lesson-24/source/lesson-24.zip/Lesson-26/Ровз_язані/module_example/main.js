import { sayHi, otherFunc } from './module1.js'

alert(sayHi('Ivan'))

otherFunc()
