export let var1 = 10

export const const1 = 50

export default function mySum(a, b) {
  return a + b
}
