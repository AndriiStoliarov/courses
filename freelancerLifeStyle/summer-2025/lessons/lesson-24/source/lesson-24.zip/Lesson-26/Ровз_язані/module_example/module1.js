export function sayHi(user) {
  otherFunc()
  return `Hello, ${user}!`
}

export function otherFunc() {
  alert('Other func')
}
