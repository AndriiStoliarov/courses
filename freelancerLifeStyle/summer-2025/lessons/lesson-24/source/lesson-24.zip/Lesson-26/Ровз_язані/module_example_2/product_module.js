export let var1 = 10

export const const1 = 50

export default function product(a, b) {
  return a * b
}
