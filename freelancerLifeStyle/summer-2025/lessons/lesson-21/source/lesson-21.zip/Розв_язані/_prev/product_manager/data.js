export const productsList = [
  {
    id: 0,
    title: 'Миша Logitech G102 Lightsync USB Black',
    link: 'https://rozetka.com.ua/ua/logitech_910_005823/p213709267/',
    srcImg: 'https://content1.rozetka.com.ua/goods/images/big/24709323.jpg',
    amount: 1,
    availableAmount: 5,
    price: 1399,
  },
  {
    id: 1,
    title: 'Телевізор Hisense QLED 43E7KQ',
    link: 'https://rozetka.com.ua/ua/hisense-43e7kq/p416904030/',
    srcImg: 'https://content.rozetka.com.ua/goods/images/big/407199878.jpg',
    amount: 2,
    availableAmount: 3,
    price: 15999,
  },
  {
    id: 2,
    title: 'Навушники Hator Hypergang 2 USB 7.1 Black',
    link: 'https://rozetka.com.ua/ua/hator-hta-940/p391482618/',
    srcImg: 'https://content2.rozetka.com.ua/goods/images/big/357433796.jpg',
    amount: 1,
    availableAmount: 15,
    price: 2299,
  },
]
