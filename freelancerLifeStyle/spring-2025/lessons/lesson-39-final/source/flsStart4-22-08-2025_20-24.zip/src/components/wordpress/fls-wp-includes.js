// Підключення шрифтів
import "./fls-wp-fonts.js";
// Підключення стилів
import "./fls-wp-styles.js";
// Підключення модулів
import "./fls-wp-modules.js";