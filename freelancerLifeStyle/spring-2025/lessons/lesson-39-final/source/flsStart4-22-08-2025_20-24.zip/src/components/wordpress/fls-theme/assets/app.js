// Підкючення функціоналу
import '../../fls-wp-includes.js'